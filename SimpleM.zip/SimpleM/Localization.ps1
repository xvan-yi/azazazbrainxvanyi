﻿# UI translations are separate from music metadata and filesystem paths.
$script:language='zh'
$script:localizedStatus=@{}
$script:english=@{
 '音量' = 'Volume'
 '上一首' = 'Previous track'
 '下一首' = 'Next track'
 '播放' = 'Play'
 '暂停' = 'Pause'
 '选择音乐文件夹' = 'Choose a music folder'
 '刷新音乐列表' = 'Refresh library'
 '隐藏到托盘' = 'Hide to tray'
 '全部歌曲' = 'All tracks'
 '当前文件夹' = 'Current folder'
 '列表循环' = 'Repeat all'
 '单曲循环' = 'Repeat one'
 '随机播放' = 'Shuffle'
 '（左键切换方案 · 右键切换范围）' = ' (Left-click: mode / Right-click: scope)'
 '顺序已调整，但保存失败。' = 'The order was changed but could not be saved.'
 '根目录' = 'Library root'
 '当前：紧凑视图 · 点击切换标准视图；右键展开列表选项' = 'Compact view / Click for standard view / Right-click for options'
 '当前：标准视图 · 点击切换紧凑视图；右键展开列表选项' = 'Standard view / Click for compact view / Right-click for options'
 '双击定位当前歌曲' = 'Double-click to locate the current track'
 '标准视图' = 'Standard view'
 '紧凑视图' = 'Compact view'
 '全部展开' = 'Expand all'
 '全部折叠' = 'Collapse all'
 '定位当前歌曲（双击标题）' = 'Locate current track (or double-click title)'
 '正在后台更新音乐列表…' = 'Updating library...'
 '无法启动扫描，请重试' = 'Could not start scanning. Please try again.'
 '扫描未完成，已保留原列表' = 'Scan incomplete. The previous list was preserved.'
 '选择歌曲' = 'Choose a track'
 '文件夹中没有音乐' = 'No music in this folder'
 '刷新失败，原列表已保留；点击重试' = 'Refresh failed. Previous list preserved; click to retry.'
 '音乐文件夹不可用' = 'Music folder unavailable'
 '正在加载音乐…' = 'Loading music...'
 '选择音乐文件夹（包含子文件夹）' = 'Choose a music folder (including subfolders)'
 '无法播放此文件，请选择其他歌曲' = 'Cannot play this file. Please choose another track.'
 '固定悬浮：保持置顶，可关闭或 Alt+S 隐藏；点击取消固定' = 'Pinned on top / Click to unpin / Hide with Close or Alt+S'
 '自动收起：失去焦点后隐藏；点击固定悬浮' = 'Hides when focus is lost / Click to pin on top'
 '正在后台导入音乐…' = 'Importing music...'
 '导入未完成' = 'Import incomplete'
 '音乐导入' = 'Music import'
 '导入失败，请检查文件夹权限' = 'Import failed. Check folder permissions.'
 '选择存放导入音乐的文件夹' = 'Choose a folder for imported music'
 '不能删除当前音乐库根目录。请选择子文件夹。' = 'Cannot delete the library root. Please select a subfolder.'
 '删除文件夹' = 'Delete folder'
 '未能移到回收站：' = 'Could not move to the Recycle Bin: '
 '删除文件夹（移到回收站）' = 'Delete folder (move to Recycle Bin)'
 '移到回收站（Del）' = 'Move to Recycle Bin (Del)'
 '显示播放器  Alt+S' = 'Show player  Alt+S'
 '隐藏播放器' = 'Hide player'
 '显示歌曲列表' = 'Show track list'
 '在文件夹中显示当前歌曲' = 'Show current track in File Explorer'
 '开机自启动' = 'Start with Windows'
 '退出' = 'Exit'
 '无法修改开机启动设置：' = 'Could not change startup settings: '
 '开机启动未设置成功，可在托盘菜单中重试。' = 'Could not enable startup. You can try again from the tray menu.'
 '快捷键被占用' = 'Hotkey unavailable'
 'Alt+S 注册失败，请双击托盘图标唤出播放器。' = 'Could not register Alt+S. Double-click the tray icon to show the player.'
 '已静音 · 中键恢复音量' = 'Muted / Middle-click to restore volume'
 '拖动调整播放进度' = 'Drag to seek'
 '搜索歌名、歌手或专辑；Esc 清空' = 'Search title, artist or album; Esc to clear'
 '音量 {0}% · 滚轮调节 · 中键静音' = 'Volume {0}% / Scroll to adjust / Middle-click to mute'
 '搜索歌名、歌手、专辑 · {0} 首' = 'Search title, artist or album / {0} tracks'
 '刷新音乐列表 · 共 {0} 首' = 'Refresh library / {0} tracks'
 '已添加 {0} 首，跳过 {1} 项，失败 {2} 项。原文件已保留。' = 'Added {0}, skipped {1}, failed {2}. Original files preserved.'
 '将文件夹及其中全部文件移到回收站？' = 'Move this folder and all its contents to the Recycle Bin?'
}
function Get-Text([string]$Key, [object[]]$Values=@()) {
 $text=$Key
 if($script:language -eq 'en' -and $script:english.ContainsKey($Key)){$text=$script:english[$Key]}
 if($Values.Count){return ($text -f $Values)}
 return $text
}
function Set-StatusText($Control,[string]$Property,[string]$Key,[object[]]$Values=@()) {
 $script:localizedStatus[$Control.Name+'.'+$Property]=@{Control=$Control;Property=$Property;Key=$Key;Values=$Values}
 $Control.$Property=Get-Text $Key $Values
}
function Set-Language([string]$Language) {
 $script:language=if($Language -eq 'en'){'en'}else{'zh'}
 foreach($entry in @(
  @($Prev,'ToolTip','上一首'),@($Next,'ToolTip','下一首'),
  @($Folder,'ToolTip','选择音乐文件夹'),@($Close,'ToolTip','隐藏到托盘'),
  @($Progress,'ToolTip','拖动调整播放进度'),@($TitleText,'ToolTip','双击定位当前歌曲'),
  @($normalView,'Header','标准视图'),@($denseView,'Header','紧凑视图'),
  @($expandAll,'Header','全部展开'),@($collapseAll,'Header','全部折叠'),
  @($locate,'Header','定位当前歌曲（双击标题）'),
  @($showItem,'Text','显示播放器  Alt+S'),@($hideItem,'Text','隐藏播放器'),
  @($listItem,'Text','显示歌曲列表'),@($revealItem,'Text','在文件夹中显示当前歌曲'),
  @($autoItem,'Text','开机自启动'),@($exitItem,'Text','退出')
 )){$entry[0].($entry[1])=Get-Text $entry[2]}
 $Play.ToolTip=if($script:playing){Get-Text '暂停'}else{Get-Text '播放'}
 foreach($entry in $script:localizedStatus.Values){$entry.Control.($entry.Property)=Get-Text $entry.Key $entry.Values}
 Update-VolumeIcon
 Update-ModeHint
 Set-CompactView $script:compactView
 Set-Pinned $script:pinned
 Update-SongList
 $chineseItem.Checked=$script:language -eq 'zh'
 $englishItem.Checked=$script:language -eq 'en'
}