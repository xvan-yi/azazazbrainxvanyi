﻿using System;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
public sealed class MusicFolderWatch : IDisposable {
 private FileSystemWatcher watcher;
 private long changed;
 private System.Collections.Concurrent.ConcurrentQueue<string> paths = new System.Collections.Concurrent.ConcurrentQueue<string>();
 public string[] Drain(){var list=new System.Collections.Generic.List<string>();string path;while(paths.TryDequeue(out path)){list.Add(path);}return list.ToArray();}
 public MusicFolderWatch(string path) {
  watcher=new FileSystemWatcher(path);
  watcher.IncludeSubdirectories=true;
  watcher.NotifyFilter=NotifyFilters.FileName|NotifyFilters.DirectoryName|NotifyFilters.LastWrite|NotifyFilters.Size;
  watcher.Changed+=OnChange;watcher.Created+=OnChange;watcher.Deleted+=OnChange;
  watcher.Renamed+=(s,e)=>{paths.Enqueue(e.OldFullPath);paths.Enqueue(e.FullPath);Mark();};watcher.Error+=(s,e)=>{paths.Enqueue("*");Mark();};
  watcher.EnableRaisingEvents=true;
 }
 private void Mark(){Interlocked.Exchange(ref changed,DateTime.UtcNow.Ticks);}
 private void OnChange(object s,FileSystemEventArgs e){paths.Enqueue(e.FullPath);Mark();}
 public bool Consume(){long t=Interlocked.Read(ref changed);return t!=0 && DateTime.UtcNow.Ticks-t>TimeSpan.TicksPerSecond && Interlocked.CompareExchange(ref changed,0,t)==t;}
 public void Dispose(){watcher.Dispose();}
}
public static class MusicHotKey {
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out int processId);
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int index);
 [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int index, int value);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
 public static void DisableSystemMenu(IntPtr h) {
  SetWindowLong(h, -16, GetWindowLong(h, -16) & ~0x00080000);
  SetWindowPos(h, IntPtr.Zero, 0, 0, 0, 0, 0x0037);
 }
 [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr h, int id, uint modifiers, uint key);
 [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr h, int id);
}
