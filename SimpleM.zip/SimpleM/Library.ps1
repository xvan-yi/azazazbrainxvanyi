﻿# Shared by discovery, drop feedback and import; extension checks ignore case.
function Test-MusicFile([string]$Path) {
    return [IO.Path]::GetExtension($Path) -in '.mp3', '.wav', '.wma', '.m4a', '.aac', '.flac'
}
# File operations are independent of the window and can be tested without launching it.
function Write-AtomicText([string]$Path, [string]$Text) {
    $directory = [IO.Path]::GetDirectoryName($Path)
    [void][IO.Directory]::CreateDirectory($directory)
    $temporary = Join-Path $directory ([IO.Path]::GetRandomFileName())
    try {
        [IO.File]::WriteAllText($temporary, $Text, (New-Object Text.UTF8Encoding($true)))
        if ([IO.File]::Exists($Path)) {
            [IO.File]::Replace($temporary, $Path, [NullString]::Value)
        } else {
            [IO.File]::Move($temporary, $Path)
        }
    } finally {
        if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
    }
}

function Save-JsonFile([string]$Path, $Value) {
    Write-AtomicText $Path ($Value | ConvertTo-Json -Depth 6)
}

function Write-PlayerError([string]$Context, $Failure) {
    try {
        [void][IO.Directory]::CreateDirectory($settings)
        $log = Join-Path $settings 'player.log'
        if ([IO.File]::Exists($log) -and (Get-Item -LiteralPath $log).Length -gt 1MB) {
            [IO.File]::Delete($log)
        }
        [IO.File]::AppendAllText($log, ('{0:u} [{1}] {2}' -f [DateTime]::Now, $Context, $Failure) + [Environment]::NewLine)
    } catch { }
}

function Get-ImportOrder([string[]]$Existing, [string[]]$Added, [string]$Before) {
    $order = New-Object 'System.Collections.Generic.List[string]'
    foreach ($path in $Existing) { if (!$order.Contains($path)) { $order.Add($path) } }
    $at = $order.IndexOf($Before)
    if ($at -lt 0) { $at = $order.Count }
    foreach ($path in $Added) {
        if (!$order.Contains($path)) { $order.Insert($at, $path); $at++ }
    }
    $order.ToArray()
}
function Convert-MusicMetadata {
 begin { $metadataShell=New-Object -ComObject Shell.Application }
 process {
  $musicFile=$_
  $cacheKey=$musicFile.FullName+"|"+$musicFile.Length+"|"+$musicFile.LastWriteTimeUtc.Ticks
  if($script:metadataCache.ContainsKey($cacheKey)){$script:metadataCache[$cacheKey]} else {
  $title=$musicFile.BaseName; $artist=''; $album=''
  $folderItem=$null;$shellFolder=$null
  try {
   $shellFolder=$metadataShell.Namespace($musicFile.DirectoryName)
   $folderItem=$shellFolder.ParseName($musicFile.Name)
   $tagTitle=[string]$folderItem.ExtendedProperty('System.Title')
   if(![string]::IsNullOrWhiteSpace($tagTitle)){$title=$tagTitle.Trim()}
   $artists=@($folderItem.ExtendedProperty('System.Music.Artist'))
   $artist=($artists | Where-Object {![string]::IsNullOrWhiteSpace([string]$_)}) -join ' / '
   $album=[string]$folderItem.ExtendedProperty('System.Music.AlbumTitle')
  } catch {
   # Unsupported or unreadable metadata falls back to the filename.
  } finally {
   if($folderItem){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($folderItem)}
   if($shellFolder){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($shellFolder)}
  }
  $track=[pscustomobject]@{FullName=$musicFile.FullName;BaseName=$musicFile.BaseName;DisplayTitle=$title;Artist=$artist;Album=$album}
  $script:metadataCache[$cacheKey]=$track; $track
  }
 }
 end {if($metadataShell){[void][Runtime.InteropServices.Marshal]::ReleaseComObject($metadataShell)}}
}

function Import-MusicFiles([string[]]$paths, [string]$destination) {
 if(!(Test-Path -LiteralPath $destination -PathType Container)){throw '请先选择可用的音乐文件夹'}
 $added=0;$skipped=0;$failed=0;$imported=New-Object 'System.Collections.Generic.List[string]'
 foreach($sourcePath in $paths){
  if(!(Test-MusicFile $sourcePath) -or !(Test-Path -LiteralPath $sourcePath -PathType Leaf)){$skipped++;continue}
  try {
   $sourceFile=Get-Item -LiteralPath $sourcePath -ErrorAction Stop
   $target=Join-Path $destination $sourceFile.Name
   if([IO.Path]::GetFullPath($sourceFile.FullName) -ieq [IO.Path]::GetFullPath($target)){$skipped++;continue}
   $n=1
   while(Test-Path -LiteralPath $target){
    $target=Join-Path $destination ($sourceFile.BaseName+' ('+$n+')'+$sourceFile.Extension);$n++
   }
   # File.Copy defaults to refusing overwrites, including a concurrent collision.
   [IO.File]::Copy($sourceFile.FullName,$target,$false)
   $imported.Add($target);$added++
  }catch{$failed++}
 }
 [pscustomobject]@{Added=$added;Skipped=$skipped;Failed=$failed;Paths=@($imported.ToArray())}
}

function Format-Time([double]$seconds) {
 $t=[TimeSpan]::FromSeconds([Math]::Max(0,$seconds))
 if($t.TotalHours -ge 1){return ('{0}:{1:00}:{2:00}' -f [int][Math]::Floor($t.TotalHours),$t.Minutes,$t.Seconds)}
 return ('{0}:{1:00}' -f [int][Math]::Floor($t.TotalMinutes),$t.Seconds)
}

function Get-TrackFolder($track){return [IO.Path]::GetDirectoryName($track.FullName)}

function Get-MusicLibrary($folder,$cache,$changes,$previous) {
  $script:metadataCache=$cache
  if($changes.Count -gt 0 -and $changes -notcontains '*'){
   $map=@{};foreach($track in $previous){$map[$track.FullName]=$track}
   foreach($changedPath in @($changes | Sort-Object -Unique)){
    $path=[IO.Path]::GetFullPath($changedPath)
    foreach($key in @($map.Keys)){if($key -ieq $path -or $key.StartsWith($path.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){$map.Remove($key)}}
    if(Test-Path -LiteralPath $path){
     $entry=Get-Item -LiteralPath $path -ErrorAction Stop
     $items=if($entry.PSIsContainer){@(Get-ChildItem -LiteralPath $path -File -Recurse -ErrorAction Stop)}else{@($entry)}
     foreach($track in @($items | Where-Object {Test-MusicFile $_.FullName} | Convert-MusicMetadata)){$map[$track.FullName]=$track}
    }
   }
   $tracks=@($map.Values | Sort-Object BaseName)
  }else{
   $tracks=@(Get-ChildItem -LiteralPath $folder -File -Recurse -ErrorAction Stop | Where-Object {Test-MusicFile $_.FullName} | Sort-Object Name | Convert-MusicMetadata)
  }
  $live=@{};foreach($track in $tracks){$live[$track.FullName]=$track}
  $clean=@{};foreach($key in $script:metadataCache.Keys){$track=$script:metadataCache[$key];if($live.ContainsKey($track.FullName) -and [object]::ReferenceEquals($live[$track.FullName],$track)){$clean[$key]=$track}}
  [pscustomobject]@{Tracks=$tracks;Cache=$clean}
 }
