﻿# Named OS objects share the single-instance state across launchers and folders.
$instanceSignal = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::AutoReset, 'Local\SimpleDesktopMusic.Activate.v1')
$instanceMutex = New-Object System.Threading.Mutex($false, 'Local\SimpleDesktopMusic.Instance.v1')
$ownsInstance = $false
try {
 try { $ownsInstance = $instanceMutex.WaitOne(0) }
 catch [System.Threading.AbandonedMutexException] { $ownsInstance = $true }
 if (!$ownsInstance) {
  [void]$instanceSignal.Set()
  return
 }
. (Join-Path $PSScriptRoot 'Library.ps1')
. (Join-Path $PSScriptRoot 'Localization.ps1')
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms
Add-Type -Path (Join-Path $PSScriptRoot 'Native.cs')
[xml]$xaml = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Player.xaml'))
$window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
foreach($name in 'Bar','Close','Folder','TitleText','Prev','Play','Next','Mode','Volume','Songs','Refresh','Progress','Elapsed','Duration','Speaker','VolumePopup','VolumeLabel','TrackDetails','DropOverlay','DropLine','Search','CompactToggle','DensityIcon','MainLayout','SearchPanel','Pin','PinGlyph') { Set-Variable -Name $name -Value $window.FindName($name) }
function Set-Icon($button, [int]$code, $tip) {
 $paths = @{
  0xE767 = 'M3,9 L7,9 L12,5 L12,19 L7,15 L3,15 Z M16,8 Q20,12 16,16 M19,5 Q25,12 19,19'
  0xE892 = 'M5,4 L5,20 M19,5 L8,12 L19,19 Z'
  0xE893 = 'M19,4 L19,20 M5,5 L16,12 L5,19 Z'
  0xE768 = 'M7,4 L19,12 L7,20 Z'
  0xE769 = 'M8,4 L8,20 M16,4 L16,20'
  0xE8EE = 'M5,7 L19,7 L16,4 M19,7 L16,10 M19,17 L5,17 L8,14 M5,17 L8,20'
  0xE8ED = 'M4,8 L4,5 L20,5 L20,8 M20,16 L20,19 L4,19 L4,16 M10,10 L12,8 L12,16 M10,16 L14,16'
  0xE8B1 = 'M3,6 L7,6 L17,18 L21,18 M18,15 L21,18 L18,21 M3,18 L7,18 L17,6 L21,6 M18,3 L21,6 L18,9'
  0xE8B7 = 'M3,7 L3,19 L21,19 L21,7 L11,7 L9,4 L3,4 Z'
  0xE72C = 'M20,10 A8,8 0 1 0 19,17 M20,4 L20,10 L14,10'
  0xE8BB = 'M5,5 L19,19 M19,5 L5,19'
 }
 $canvas=New-Object Windows.Controls.Canvas
 $canvas.Width=24; $canvas.Height=24
 $path=New-Object Windows.Shapes.Path
 $path.Data=[Windows.Media.Geometry]::Parse($paths[$code])
 $path.Stroke=[Windows.Media.Brushes]::WhiteSmoke
 $path.StrokeThickness=1.7
 $path.StrokeLineJoin='Round'
 $path.StrokeStartLineCap='Round'; $path.StrokeEndLineCap='Round'
 [void]$canvas.Children.Add($path)
 $box=New-Object Windows.Controls.Viewbox
 $box.Width=18; $box.Height=18; $box.Child=$canvas
 $button.Content=$box; $button.ToolTip=$tip
}
function Update-VolumeIcon {
 # Reuse the icon and parsed geometries while dragging the volume slider.
 if(!$script:volumeIcons){
  $speakerShape='M2,9 L5,9 L9,5 L9,19 L5,15 L2,15 Z '
  $waves=@(
   'M14,9 L20,15 M20,9 L14,15',
   'M12,10 Q14,12 12,14',
   'M12,10 Q14,12 12,14 M15,7 Q19,12 15,17',
   'M12,10 Q14,12 12,14 M15,7 Q19,12 15,17 M18,4 Q24,12 18,20'
  )
  $script:volumeIcons=@($waves | ForEach-Object {[Windows.Media.Geometry]::Parse($speakerShape+$_)})
 }
 $level=if($Volume.Value -le 0){0}elseif($Volume.Value -le (1.0/3)){1}elseif($Volume.Value -le (2.0/3)){2}else{3}
 $Speaker.Content.Child.Children[0].Data=$script:volumeIcons[$level]
 $percent=[Math]::Round($Volume.Value*100)
 $Speaker.ToolTip=if($level -eq 0){(Get-Text '已静音 · 中键恢复音量')}else{(Get-Text '音量 {0}% · 滚轮调节 · 中键静音' @($percent))}
}
Set-Icon $Speaker 0xE767 (Get-Text '音量')
Update-VolumeIcon
Set-Icon $Prev 0xE892 (Get-Text '上一首')
Set-Icon $Next 0xE893 (Get-Text '下一首')
Set-Icon $Play 0xE768 (Get-Text '播放')
Set-Icon $Folder 0xE8B7 (Get-Text '选择音乐文件夹')
Set-Icon $Refresh 0xE72C (Get-Text '刷新音乐列表')
Set-Icon $Close 0xE8BB (Get-Text '隐藏到托盘')
Set-StatusText $TitleText 'Text' '选择音乐文件夹'
Set-StatusText $Refresh 'ToolTip' '刷新音乐列表'
$script:currentFolder = $null
$player = New-Object System.Windows.Media.MediaPlayer
$player.Volume = 0.7
$script:updatingProgress=$false

function Reset-Progress {
 $script:updatingProgress=$true
 $Progress.IsEnabled=$false;$Progress.Value=0;$Progress.Maximum=1
 $Elapsed.Text='0:00';$Duration.Text='0:00'
 $script:updatingProgress=$false
}
$Progress.Add_ValueChanged({
 if(!$script:updatingProgress -and $Progress.IsEnabled){
  $player.Position=[TimeSpan]::FromSeconds($Progress.Value)
  $Elapsed.Text=Format-Time $Progress.Value
 }
})
function Stop-Playback {
 $player.Close()
 Reset-Progress
 $script:playing=$false
 $script:index=-1
 Set-Icon $Play 0xE768 (Get-Text '播放')
}
function Sync-PlaybackProgress {
 if(!$window.IsVisible -or $script:index -lt 0){return}
 $script:updatingProgress=$true
 try {
  $position=[Math]::Max(0.0,$player.Position.TotalSeconds)
  $known=$player.NaturalDuration.HasTimeSpan -and $player.NaturalDuration.TimeSpan.TotalSeconds -gt 0
  if($known){
   $total=$player.NaturalDuration.TimeSpan.TotalSeconds
   $Progress.Maximum=$total
   $Progress.IsEnabled=$true
   $Duration.Text=Format-Time $total
   if(!$Progress.IsMouseCaptureWithin){$Progress.Value=[Math]::Min($total,$position)}
  }else{
   $Progress.IsEnabled=$false
   $Duration.Text='--:--'
  }
  # Elapsed time must keep updating even when duration is not yet available.
  if(!$Progress.IsMouseCaptureWithin){$Elapsed.Text=Format-Time $position}
 }finally{$script:updatingProgress=$false}
}
$player.Add_MediaOpened({Sync-PlaybackProgress})
$progressTimer=New-Object Windows.Threading.DispatcherTimer
$progressTimer.Interval=[TimeSpan]::FromMilliseconds(250)
$progressTimer.Add_Tick({Sync-PlaybackProgress})
$window.Add_IsVisibleChanged({
 if($window.IsVisible){Sync-PlaybackProgress;$progressTimer.Start()}else{$progressTimer.Stop()}
})
$script:files = @(); $script:index = -1; $script:playing = $false; $script:loopMode = 0
$settings = Join-Path $env:LOCALAPPDATA 'SimpleDesktopMusic'
$config = Join-Path $settings 'folder.txt'
$script:metadataCache=@{}
$preferences=Join-Path $settings 'preferences.json'
function Save-Preferences {
 try {
  $data=@{Language=$script:language;Volume=$Volume.Value;Mode=$script:loopMode;Scope=$script:playScope;ListVisible=$script:listVisible;Compact=$script:compactView;PinnedV2=$script:pinned;Topmost=$window.Topmost;Left=$window.Left;Top=$window.Top}
  Save-JsonFile $preferences $data
 } catch { Write-PlayerError '保存偏好' $_ }
}
$script:playScope='all'
$script:shuffleSeen=@{}
$script:shuffleKey=''
$script:playHistory=New-Object 'System.Collections.Generic.List[string]'
function Get-PlayQueue {
 $tracks=@($script:files)
 if($script:playScope -eq 'folder' -and $script:index -ge 0){
  $folder=Get-TrackFolder $script:files[$script:index]
  $tracks=@($tracks | Where-Object {(Get-TrackFolder $_) -ieq $folder})
 }
 foreach($group in @($tracks | Group-Object {Get-TrackFolder $_} | Sort-Object Name)){foreach($track in $group.Group){$track}}
}
function Update-ModeHint {
 $scope=(Get-Text '全部歌曲')
 if($script:playScope -eq 'folder'){
  $scope=(Get-Text '当前文件夹')
  if($script:index -ge 0){$scope+='：'+[IO.Path]::GetFileName((Get-TrackFolder $script:files[$script:index]))}
 }
 if(!$script:modeFrame){
  $script:modeFrame=New-Object Windows.Controls.Border
  $script:modeFrame.Width=26;$script:modeFrame.Height=26
  $script:modeFrame.BorderThickness=New-Object Windows.Thickness(1)
  $script:modeFrame.SnapsToDevicePixels=$true
  $Mode.Content=$script:modeFrame
 }
 $tip=(@((Get-Text '列表循环'),(Get-Text '单曲循环'),(Get-Text '随机播放'))[$script:loopMode])+' · '+$scope+(Get-Text '（左键切换方案 · 右键切换范围）')
 $iconHolder=New-Object Windows.Controls.Button
 Set-Icon $iconHolder (@(0xE8EE,0xE8ED,0xE8B1)[$script:loopMode]) $tip
 $icon=$iconHolder.Content;$iconHolder.Content=$null
 $icon.HorizontalAlignment='Center';$icon.VerticalAlignment='Center'
 $script:modeFrame.Child=$icon
 $script:modeFrame.BorderBrush=if($script:playScope -eq 'folder'){[Windows.Media.Brushes]::Silver}else{[Windows.Media.Brushes]::Transparent}
 $Mode.ToolTip=$tip
 $script:modeFrame.InvalidateVisual()
}
function Record-Track($path) {
 $queue=@(Get-PlayQueue)
 $key=$script:playScope+'|'+(($queue.FullName | Sort-Object) -join '|')
 if($key -ne $script:shuffleKey){$script:shuffleSeen=@{};$script:shuffleKey=$key;$script:playHistory.Clear()}
 $script:shuffleSeen[$path]=$true
}
function Next-Track {
 $queue=@(Get-PlayQueue);if(!$queue.Count){return}
 $current=$null;if($script:index -ge 0){$current=$script:files[$script:index].FullName;Record-Track $current}
 if($script:loopMode -eq 2){
  $available=@($queue | Where-Object {!$script:shuffleSeen.ContainsKey($_.FullName)})
  if(!$available.Count){$script:shuffleSeen=@{};$available=@($queue | Where-Object {$queue.Count -eq 1 -or $_.FullName -ine $current})}
  $track=$available[(Get-Random -Maximum $available.Count)]
 }else{
  $position=-1;for($j=0;$j -lt $queue.Count;$j++){if($queue[$j].FullName -ieq $current){$position=$j;break}}
  $track=$queue[($position+1)%$queue.Count]
 }
 Start-Song ([Array]::IndexOf($script:files,$track))
}
function Previous-Track {
 $queue=@(Get-PlayQueue);if(!$queue.Count){return}
 if($script:loopMode -eq 2){
  while($script:playHistory.Count){
   $path=$script:playHistory[$script:playHistory.Count-1];$script:playHistory.RemoveAt($script:playHistory.Count-1)
   $track=@($queue | Where-Object {$_.FullName -ieq $path})
   if($track.Count){Start-Song ([Array]::IndexOf($script:files,$track[0])) $true;return}
  }
  return
 }
 $position=0
 if($script:index -ge 0){for($j=0;$j -lt $queue.Count;$j++){if($queue[$j].FullName -ieq $script:files[$script:index].FullName){$position=$j;break}}}
 Start-Song ([Array]::IndexOf($script:files,$queue[($position-1+$queue.Count)%$queue.Count]))
}

Update-ModeHint
$orderFile=Join-Path $settings 'playlist-order.json'
$script:folderOrders=@{}
try {
 if(Test-Path -LiteralPath $orderFile){
  $stored=Get-Content -LiteralPath $orderFile -Raw | ConvertFrom-Json
  foreach($property in $stored.PSObject.Properties){$script:folderOrders[$property.Name]=@($property.Value)}
 }
}catch{}
function Restore-PlaylistOrder {
 if(!$script:currentFolder -or !$script:folderOrders.ContainsKey($script:currentFolder)){return}
 $remaining=@{};foreach($track in $script:files){$remaining[$track.FullName]=$track}
 $ordered=New-Object 'System.Collections.Generic.List[object]'
 foreach($path in $script:folderOrders[$script:currentFolder]){if($remaining.ContainsKey($path)){$ordered.Add($remaining[$path]);$remaining.Remove($path)}}
 foreach($track in $script:files){if($remaining.ContainsKey($track.FullName)){$ordered.Add($track);$remaining.Remove($track.FullName)}}
 $script:files=@($ordered.ToArray())
}
function Move-PlaylistTrack([string]$sourcePath,[int]$insertAt) {
 $from=-1
 for($i=0;$i -lt $script:files.Count;$i++){if($script:files[$i].FullName -ieq $sourcePath){$from=$i;break}}
 if($from -lt 0){return}
 $currentPath=$null
 if($script:index -ge 0){$currentPath=$script:files[$script:index].FullName}
 $list=New-Object 'System.Collections.Generic.List[object]'
 foreach($track in $script:files){$list.Add($track)}
 $moving=$list[$from];$list.RemoveAt($from)
 if($insertAt -gt $from){$insertAt--}
 $insertAt=[Math]::Max(0,[Math]::Min($list.Count,$insertAt))
 $list.Insert($insertAt,$moving)
 $script:files=@($list.ToArray());Update-SongList
 $script:index=-1
 for($i=0;$i -lt $script:files.Count;$i++){if($script:files[$i].FullName -ieq $currentPath){$script:index=$i;break}}
 $Songs.SelectedItem=$moving;$Songs.ScrollIntoView($moving)
 $script:folderOrders[$script:currentFolder]=@($script:files | ForEach-Object {$_.FullName})
 try {
  Save-JsonFile $orderFile $script:folderOrders
 }catch{[void][Windows.MessageBox]::Show((Get-Text '顺序已调整，但保存失败。'),'SimpleM')}
}
function Get-DropPosition($pos) {
 $insert=$Songs.Items.Count;$y=0
 for($j=0;$j -lt $Songs.Items.Count;$j++){
  $row=$Songs.ItemContainerGenerator.ContainerFromIndex($j)
  if(!$row){continue}
  $top=$row.TranslatePoint((New-Object Windows.Point(0,0)),$Songs).Y
  $bottom=$top+$row.ActualHeight
  $y=$bottom
  $threshold=$top+$row.ActualHeight/2
  if($null -ne $script:previewIndex){if($script:previewIndex -le $j){$threshold+=4}else{$threshold-=4}}
  if($pos.Y -lt $threshold){$insert=$j;$y=$top;break}
 }
 [pscustomobject]@{Index=$insert;Y=[Math]::Max(1,[Math]::Min($Songs.ActualHeight-4,$y))}
}
function Update-DropPreview($pos) {
 $placement=Get-DropPosition $pos
 if($script:sortingSource){
  $target=$null
  if($placement.Index -lt $Songs.Items.Count){$target=$Songs.Items[$placement.Index]}
  if(!$target -or $target.IsFolder){if($placement.Index -gt 0){$target=$Songs.Items[$placement.Index-1]}}
  if(!$target -or $target.IsFolder -or (Get-TrackFolder $target) -ine [IO.Path]::GetDirectoryName($script:sortingSource)){$DropLine.Visibility='Collapsed';$script:previewIndex=$null;return}
 }
 $script:previewIndex=$placement.Index
 $DropLine.Width=[Math]::Max(0,$Songs.ActualWidth-20)
 [Windows.Controls.Canvas]::SetLeft($DropLine,4)
 [Windows.Controls.Canvas]::SetTop($DropLine,[Math]::Round($placement.Y))
 $DropLine.Visibility='Visible'
}
$dragScrollTimer=New-Object Windows.Threading.DispatcherTimer
$dragScrollTimer.Interval=[TimeSpan]::FromMilliseconds(130)
$dragScrollTimer.Add_Tick({
 if(!$script:dragPosition){return}
 $pos=$script:dragPosition
 $viewer=$Songs.Template.FindName('PART_ScrollViewer',$Songs)
 if(!$viewer){return}
 if($pos.Y -lt 28){$viewer.LineUp()}elseif($pos.Y -gt $Songs.ActualHeight-28){$viewer.LineDown()}else{return}
 $Songs.UpdateLayout();Update-DropPreview $pos
})
function Clear-DropPreview {
 $script:importPlacement=$null
 $DropLine.Visibility='Collapsed';$script:previewIndex=$null;$script:dragPosition=$null;$dragScrollTimer.Stop()
}
$window.Add_PreviewDragLeave({
 param($sender,$e)
 $pos=$e.GetPosition($Songs)
 # Child rows emit DragLeave while the pointer is still inside the playlist.
 if($pos.X -lt 0 -or $pos.X -gt $Songs.ActualWidth -or $pos.Y -lt 0 -or $pos.Y -gt $Songs.ActualHeight){Clear-DropPreview}
})
$script:dragTrack=$null
$Songs.Add_PreviewMouseLeftButtonDown({
 param($sender,$e)
 $item=[Windows.Controls.ItemsControl]::ContainerFromElement($Songs,[Windows.DependencyObject]$e.OriginalSource)
 $script:dragTrack=$null
 if($item -is [Windows.Controls.ListBoxItem] -and !$item.Content.IsFolder){$script:dragTrack=$item.Content.FullName;$script:dragStart=$e.GetPosition($Songs)}
})
$Songs.Add_PreviewMouseLeftButtonUp({$script:dragTrack=$null})
$Songs.Add_PreviewMouseMove({
 param($sender,$e)
 if($Search.Text.Trim()){return}
 if(!$script:dragTrack -or $e.LeftButton -ne [Windows.Input.MouseButtonState]::Pressed){return}
 $point=$e.GetPosition($Songs)
 if([Math]::Abs($point.Y-$script:dragStart.Y) -lt [Windows.SystemParameters]::MinimumVerticalDragDistance -and [Math]::Abs($point.X-$script:dragStart.X) -lt [Windows.SystemParameters]::MinimumHorizontalDragDistance){return}
 $data=New-Object Windows.DataObject
 $script:sortingSource=$script:dragTrack
 $data.SetData('SimpleDesktopMusic.Track',$script:dragTrack)
 $script:dragTrack=$null
 $script:sortingDrag=$true
 try {[void][Windows.DragDrop]::DoDragDrop($Songs,$data,[Windows.DragDropEffects]::Move)}finally{$script:sortingDrag=$false;$script:sortingSource=$null;Clear-DropPreview}
 $e.Handled=$true
})
$script:collapsedFolders=@{}
$collapseFile=Join-Path $settings 'collapsed-folders.json'
try{if(Test-Path $collapseFile){$state=Get-Content $collapseFile -Raw | ConvertFrom-Json;foreach($prop in $state.PSObject.Properties){$script:collapsedFolders[$prop.Name]=[bool]$prop.Value}}}catch{}

function Update-SongList {
 $query=$Search.Text.Trim()
 $visible=@($script:files | Where-Object {!$query -or ($_.DisplayTitle+' '+$_.Artist+' '+$_.Album).IndexOf($query,[StringComparison]::OrdinalIgnoreCase) -ge 0})
 $selected=$Songs.SelectedItem
 $rows=New-Object 'System.Collections.Generic.List[object]'
 $groups=@($visible | Group-Object {Get-TrackFolder $_} | Sort-Object Name)
 foreach($group in $groups){
  $folder=$group.Name
  if(!$query){
   $hiddenByParent=$false
   foreach($ancestor in $script:collapsedFolders.Keys){if($script:collapsedFolders[$ancestor] -and $folder.StartsWith($ancestor.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){$hiddenByParent=$true;break}}
   if($hiddenByParent){continue}
  }
  $label=$folder
  if($script:currentFolder){
   $root=$script:currentFolder.TrimEnd('\')
   if($folder -ieq $root){$label=(Get-Text '根目录')}elseif($folder.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){$label=$folder.Substring($root.Length+1)}
  }
  $closed=!$query -and $script:collapsedFolders[$folder]
  $arrow=if($closed){'▸'}else{'▾'}
  $rows.Add([pscustomobject]@{IsFolder=$true;FolderPath=$folder;DisplayTitle="$arrow  $label  ($($group.Count))";FullName=$null})
  if(!$closed){foreach($track in $group.Group){$rows.Add($track)}}
 }
 $Songs.ItemsSource=@($rows.ToArray())
 if($selected -and $selected.IsFolder){foreach($entry in $rows){if($entry.IsFolder -and $entry.FolderPath -eq $selected.FolderPath){$Songs.SelectedItem=$entry;break}}}
 elseif($selected -and !$selected.IsFolder -and $rows.Contains($selected)){$Songs.SelectedItem=$selected}
 elseif($script:index -ge 0 -and $script:index -lt $script:files.Count -and $rows.Contains($script:files[$script:index])){$Songs.SelectedItem=$script:files[$script:index]}
 $Search.ToolTip=(Get-Text '搜索歌名、歌手、专辑 · {0} 首' @($visible.Count))
}
function Toggle-Folder($header){
 $folderPath=$header.FolderPath
 if($Search.Text.Trim()){return}
 $script:collapsedFolders[$header.FolderPath]=!$script:collapsedFolders[$header.FolderPath]
 try{Save-JsonFile $collapseFile $script:collapsedFolders}catch{Write-PlayerError '保存折叠状态' $_}
 Update-SongList
 foreach($entry in $Songs.Items){if($entry.IsFolder -and $entry.FolderPath -eq $folderPath){$Songs.SelectedItem=$entry;break}}
 Focus-SongList
}
$Songs.Add_PreviewMouseLeftButtonDown({param($sender,$e)
 $row=[Windows.Controls.ItemsControl]::ContainerFromElement($Songs,[Windows.DependencyObject]$e.OriginalSource)
 if($row -is [Windows.Controls.ListBoxItem] -and $row.Content.IsFolder){Toggle-Folder $row.Content;$script:dragTrack=$null;$e.Handled=$true}
})
$Search.Add_TextChanged({Update-SongList})
$Search.Add_PreviewKeyDown({param($sender,$e) if($e.Key -eq 'Escape'){$Search.Clear();$e.Handled=$true}})
$script:unmutedVolume=0.7
function Adjust-VolumeWheel($e) {
 if($e.Handled){return}
 $Volume.Value=[Math]::Max(0.0,[Math]::Min(1.0,$Volume.Value+([Math]::Sign($e.Delta)*0.05)))
 $e.Handled=$true
}
$window.Add_PreviewMouseWheel({param($sender,$e) if($VolumePopup.IsOpen){Adjust-VolumeWheel $e}})
# Popup has its own window; listen on its content as well.
$VolumePopup.Child.Add_PreviewMouseWheel({param($sender,$e) if($VolumePopup.IsOpen){Adjust-VolumeWheel $e}})
$Speaker.Add_PreviewMouseWheel({param($sender,$e) Adjust-VolumeWheel $e})
$Speaker.Add_PreviewMouseDown({param($sender,$e)
 if($e.ChangedButton -eq [Windows.Input.MouseButton]::Middle){
  if($Volume.Value -gt 0){$script:unmutedVolume=$Volume.Value;$Volume.Value=0}else{$Volume.Value=$script:unmutedVolume}
  $e.Handled=$true
 }
})

$script:folderWatch=$null
function Watch-MusicFolder {
 if($script:folderWatch){$script:folderWatch.Dispose();$script:folderWatch=$null}
 try{$script:folderWatch=New-Object MusicFolderWatch($script:currentFolder)}catch{}
}
$watchTimer=New-Object Windows.Threading.DispatcherTimer
$watchTimer.Interval=[TimeSpan]::FromMilliseconds(1000)
$watchTimer.Add_Tick({
 if($script:sortingDrag -or $script:dragPosition){return}
 if($script:folderWatch -and $script:folderWatch.Consume()){
  Request-MusicScan ($script:folderWatch.Drain())
 }
})
$watchTimer.Start()
$script:compactView=$false
$script:standardRowStyle=$Songs.ItemContainerStyle
function Set-CompactView([bool]$enabled){
 $script:compactView=$enabled
 if($enabled){
  $style=New-Object Windows.Style([Windows.Controls.ListBoxItem],$script:standardRowStyle)
  $style.Setters.Add((New-Object Windows.Setter([Windows.Controls.Control]::PaddingProperty,(New-Object Windows.Thickness(7,3,7,3)))))
  $Songs.ItemContainerStyle=$style;$Songs.FontSize=11
 }else{$Songs.ItemContainerStyle=$script:standardRowStyle;$Songs.FontSize=14}
 $normalView.IsChecked=!$enabled;$denseView.IsChecked=$enabled
 $CompactToggle.ToolTip=if($enabled){(Get-Text '当前：紧凑视图 · 点击切换标准视图；右键展开列表选项')}else{(Get-Text '当前：标准视图 · 点击切换紧凑视图；右键展开列表选项')}
 $DensityIcon.Data=[Windows.Media.Geometry]::Parse($(if($enabled){'M1,2 L15,2 M1,6 L15,6 M1,10 L15,10 M1,14 L15,14'}else{'M1,2 L15,2 M1,8 L15,8 M1,14 L15,14'}))
}
function Set-AllFolders([bool]$collapsed){
 foreach($track in $script:files){$script:collapsedFolders[(Get-TrackFolder $track)]=$collapsed}
 if($Search.Text){$Search.Clear()}
 Update-SongList
 try{Save-JsonFile $collapseFile $script:collapsedFolders}catch{Write-PlayerError '保存折叠状态' $_}
}
function Locate-CurrentSong {
 Set-ListVisible $true
 if($script:index -lt 0 -or $script:index -ge $script:files.Count){return}
 $track=$script:files[$script:index]
 $Search.Clear()
 $directory=Get-TrackFolder $track
 while($directory){$script:collapsedFolders[$directory]=$false;if($directory -ieq $script:currentFolder){break};$directory=[IO.Path]::GetDirectoryName($directory)}
 Update-SongList;$Songs.SelectedItem=$track;Focus-SongList
}
Set-StatusText $TitleText 'ToolTip' '双击定位当前歌曲'
$TitleText.Add_MouseLeftButtonDown({param($sender,$e) if($e.ClickCount -eq 2){Locate-CurrentSong;$e.Handled=$true}})
$viewMenu=New-Object Windows.Controls.ContextMenu
$normalView=New-Object Windows.Controls.MenuItem;$normalView.Header=(Get-Text '标准视图');$normalView.IsCheckable=$true
$denseView=New-Object Windows.Controls.MenuItem;$denseView.Header=(Get-Text '紧凑视图');$denseView.IsCheckable=$true
$normalView.Add_Click({Set-CompactView $false;Save-Preferences})
$denseView.Add_Click({Set-CompactView $true;Save-Preferences})
[void]$viewMenu.Items.Add($normalView);[void]$viewMenu.Items.Add($denseView)
[void]$viewMenu.Items.Add((New-Object Windows.Controls.Separator))
$expandAll=New-Object Windows.Controls.MenuItem;$expandAll.Header=(Get-Text '全部展开');$expandAll.Add_Click({Set-AllFolders $false})
$collapseAll=New-Object Windows.Controls.MenuItem;$collapseAll.Header=(Get-Text '全部折叠');$collapseAll.Add_Click({Set-AllFolders $true})
$locate=New-Object Windows.Controls.MenuItem;$locate.Header=(Get-Text '定位当前歌曲（双击标题）');$locate.Add_Click({Locate-CurrentSong})
[void]$viewMenu.Items.Add($expandAll);[void]$viewMenu.Items.Add($collapseAll);[void]$viewMenu.Items.Add($locate)
$CompactToggle.Add_Click({Set-CompactView (!$script:compactView);Save-Preferences})
$CompactToggle.ContextMenu=$viewMenu
Set-CompactView $false

function Show-TrackMetadata($track) {
 $script:localizedStatus.Remove('TitleText.Text')
 $TitleText.Text=$track.DisplayTitle
 $TrackDetails.Text=(@($track.Artist,$track.Album) | Where-Object {![string]::IsNullOrWhiteSpace($_)}) -join ' · '
 if($TrackDetails.Text){$TrackDetails.Visibility='Visible'}else{$TrackDetails.Visibility='Collapsed'}
}
$script:scanJob=$null;$script:scanPending=$false
function Request-MusicScan([string[]]$changes=@()) {
 if(!$script:currentFolder -or !(Test-Path -LiteralPath $script:currentFolder -PathType Container)){return}
 if($script:scanJob){$script:scanPending=$true;return}
 $worker=[PowerShell]::Create()
 $runspace=$null
 try {
 $runspace=[RunspaceFactory]::CreateRunspace();$runspace.ApartmentState='STA';$runspace.ThreadOptions='ReuseThread';$runspace.Open();$worker.Runspace=$runspace
 $task={param($libraryPath,$folder,$cache,$changes,$previous)
  $ErrorActionPreference='Stop'
  . $libraryPath
  Get-MusicLibrary $folder $cache $changes $previous
 }
 [void]$worker.AddScript($task.ToString()).AddArgument((Join-Path $PSScriptRoot 'Library.ps1')).AddArgument($script:currentFolder).AddArgument($script:metadataCache.Clone()).AddArgument($changes).AddArgument($script:files)
 $script:scanJob=@{Worker=$worker;Runspace=$runspace;Folder=$script:currentFolder;Async=$worker.BeginInvoke()}
 $scanTimer.Start()
 Set-StatusText $Refresh 'ToolTip' '正在后台更新音乐列表…'
 } catch {
  $worker.Dispose()
  if($runspace){$runspace.Dispose()}
  $script:scanJob=$null
  Write-PlayerError '启动扫描' $_
  Set-StatusText $Refresh 'ToolTip' '无法启动扫描，请重试'
 }
}
$scanTimer=New-Object Windows.Threading.DispatcherTimer
$scanTimer.Interval=[TimeSpan]::FromMilliseconds(150)
$scanTimer.Add_Tick({
 if(!$script:scanJob -or !$script:scanJob.Async.IsCompleted -or $script:sortingDrag){return}
 $scanTimer.Stop();$job=$script:scanJob;$script:scanJob=$null
 try{
  $result=@($job.Worker.EndInvoke($job.Async))
  if($job.Worker.HadErrors -or !$result.Count){throw (Get-Text '扫描未完成，已保留原列表')}
  if($job.Folder -eq $script:currentFolder){
   $current=$null;if($script:index -ge 0){$current=$script:files[$script:index].FullName}
   $selectedPath=$null;if($Songs.SelectedItem -and !$Songs.SelectedItem.IsFolder){$selectedPath=$Songs.SelectedItem.FullName}
   $script:files=@($result[0].Tracks);$script:metadataCache=$result[0].Cache
   Restore-PlaylistOrder;$script:index=-1
   for($j=0;$j -lt $script:files.Count;$j++){if($script:files[$j].FullName -eq $current){$script:index=$j;break}}
   Update-SongList
   if($selectedPath){foreach($track in $script:files){if($track.FullName -eq $selectedPath -and $Songs.Items.Contains($track)){$Songs.SelectedItem=$track;break}}}
   if($script:index -ge 0){Show-TrackMetadata $script:files[$script:index]}else{
    Stop-Playback
    $TrackDetails.Visibility='Collapsed';Set-StatusText $TitleText 'Text' $(if($script:files.Count){'选择歌曲'}else{'文件夹中没有音乐'})
   }
   Set-StatusText $Refresh 'ToolTip' '刷新音乐列表 · 共 {0} 首' @($script:files.Count)
  }
 }catch{Write-PlayerError '扫描音乐库' $_;Set-StatusText $Refresh 'ToolTip' '刷新失败，原列表已保留；点击重试'}finally{$job.Worker.Dispose();$job.Runspace.Dispose()}
 if($script:scanPending){$script:scanPending=$false;Request-MusicScan}
})

function Load-Folder($path) {
 if(!(Test-Path -LiteralPath $path -PathType Container)){Set-StatusText $TitleText 'Text' '音乐文件夹不可用';return}
 $script:currentFolder=[IO.Path]::GetFullPath($path);Watch-MusicFolder
 Stop-Playback
 $script:files=@();Update-SongList;Set-StatusText $TitleText 'Text' '正在加载音乐…';$TrackDetails.Visibility='Collapsed'
 try{Write-AtomicText $config $script:currentFolder}catch{Write-PlayerError '保存音乐库' $_}
 Request-MusicScan
}
function Start-Song([int]$i, [bool]$fromHistory=$false) {
 if ($i -lt 0 -or $i -ge $script:files.Count) { return }
 if(!$fromHistory -and $script:index -ge 0 -and $i -ne $script:index){$script:playHistory.Add($script:files[$script:index].FullName);if($script:playHistory.Count -gt 300){$script:playHistory.RemoveAt(0)}}
 $script:index=$i
 Record-Track $script:files[$script:index].FullName;Update-ModeHint
 $file=$script:files[$script:index]; Reset-Progress; $player.Close(); $player.Open([uri]$file.FullName); $player.Play()
 $script:playing=$true; Set-Icon $Play 0xE769 (Get-Text '暂停'); Show-TrackMetadata $file
 $Songs.SelectedItem=$script:files[$script:index]; if($Songs.SelectedItem){$Songs.ScrollIntoView($Songs.SelectedItem)}
}
$Refresh.Add_Click({Request-MusicScan})
$Folder.Add_Click({ $dialog=New-Object System.Windows.Forms.FolderBrowserDialog; $dialog.Description=(Get-Text '选择音乐文件夹（包含子文件夹）'); if($dialog.ShowDialog() -eq 'OK'){Load-Folder $dialog.SelectedPath}; $dialog.Dispose() })
$Play.Add_Click({ if($script:index -lt 0){Start-Song 0} elseif($script:playing){$player.Pause();$script:playing=$false;Set-Icon $Play 0xE768 (Get-Text '播放')} else {$player.Play();$script:playing=$true;Set-Icon $Play 0xE769 (Get-Text '暂停')} })
# Handle Space before the focused button or slider receives it.
$window.Add_PreviewKeyDown({
 param($sender, $eventArgs)
 if($Search.IsKeyboardFocusWithin){return}
 if(($eventArgs.Key -eq [System.Windows.Input.Key]::Space -or ($eventArgs.Key -eq [System.Windows.Input.Key]::System -and $eventArgs.SystemKey -eq [System.Windows.Input.Key]::Space)) -and ([System.Windows.Input.Keyboard]::Modifiers -band ([System.Windows.Input.ModifierKeys]::Control -bor [System.Windows.Input.ModifierKeys]::Windows)) -eq 0){
  $eventArgs.Handled=$true
  if(!$eventArgs.IsRepeat){
   $Play.RaiseEvent((New-Object Windows.RoutedEventArgs([Windows.Controls.Button]::ClickEvent)))
  }
 }
})
$window.Add_PreviewKeyUp({
 param($sender, $eventArgs)
 if($eventArgs.Key -eq [System.Windows.Input.Key]::Space -or ($eventArgs.Key -eq [System.Windows.Input.Key]::System -and $eventArgs.SystemKey -eq [System.Windows.Input.Key]::Space)){$eventArgs.Handled=$true}
})
$Prev.Add_Click({Previous-Track})
$Next.Add_Click({Next-Track})
$Mode.Add_Click({
 $script:loopMode=($script:loopMode+1)%3
 $script:shuffleKey='';$script:shuffleSeen=@{};$script:playHistory.Clear()
 Update-ModeHint;Save-Preferences
})
$Mode.ContextMenu=$null
$Mode.Add_PreviewMouseRightButtonUp({
 param($sender,$e)
 $e.Handled=$true
 $script:playScope=if($script:playScope -eq 'all'){'folder'}else{'all'}
 $script:shuffleKey='';$script:shuffleSeen=@{};$script:playHistory.Clear()
 Update-ModeHint;Save-Preferences
})
$Songs.Add_MouseDoubleClick({if($Songs.SelectedItem -and !$Songs.SelectedItem.IsFolder){Start-Song ([Array]::IndexOf($script:files,$Songs.SelectedItem))}})
$script:listVisible=$true
function Set-ListVisible([bool]$visible){
 $script:listVisible=$visible
 $SearchPanel.Visibility=if($visible){'Visible'}else{'Collapsed'}
 $Songs.Visibility=if($visible){'Visible'}else{'Collapsed'}
 $DropOverlay.Visibility=if($visible){'Visible'}else{'Collapsed'}
 $MainLayout.RowDefinitions[4].Height=if($visible){[Windows.GridLength]::new(36)}else{[Windows.GridLength]::new(0)}
 $MainLayout.RowDefinitions[5].Height=if($visible){[Windows.GridLength]::new(1,[Windows.GridUnitType]::Star)}else{[Windows.GridLength]::new(0)}
 $window.Height=if($visible){540}else{244}
 if($visible){$area=[Windows.SystemParameters]::WorkArea;if($window.Top+$window.Height -gt $area.Bottom){$window.Top=[Math]::Max($area.Top,$area.Bottom-$window.Height)}}
 if($listItem){$listItem.Checked=$visible}
}
function Focus-SongList {
 if(!$script:listVisible){return}
 if($Songs.SelectedIndex -lt 0 -and $Songs.Items.Count -gt 0){$Songs.SelectedIndex=0;for($i=0;$i -lt $Songs.Items.Count;$i++){if(!$Songs.Items[$i].IsFolder){$Songs.SelectedIndex=$i;break}}}
 [void]$Songs.Focus()
 if($Songs.SelectedItem){
  $Songs.ScrollIntoView($Songs.SelectedItem);$Songs.UpdateLayout()
  $row=$Songs.ItemContainerGenerator.ContainerFromItem($Songs.SelectedItem)
  if($row){[void]$row.Focus()}
 }
}
$window.Add_PreviewKeyDown({
 param($sender,$e)
 if($Search.IsKeyboardFocusWithin){return}
 $key=$e.Key
 if($key -eq [Windows.Input.Key]::System){$key=$e.SystemKey}
 if($key -eq [Windows.Input.Key]::Up -or $key -eq [Windows.Input.Key]::Down){
  $e.Handled=$true
  if(!$Songs.Items.Count){return}
  $next=$Songs.SelectedIndex
  if($next -lt 0){$next=0}elseif($key -eq [Windows.Input.Key]::Up){$next=($next-1+$Songs.Items.Count)%$Songs.Items.Count}else{$next=($next+1)%$Songs.Items.Count}
  $Songs.SelectedIndex=$next;Focus-SongList
 }elseif($key -eq [Windows.Input.Key]::End){
  $e.Handled=$true
  if($e.IsRepeat){return}
  for($step=1;$step -le $Songs.Items.Count;$step++){
   $j=($Songs.SelectedIndex+$step)%$Songs.Items.Count
   if($Songs.Items[$j].IsFolder){$Songs.SelectedIndex=$j;Focus-SongList;break}
  }
 }elseif($key -eq [Windows.Input.Key]::Return){
  $e.Handled=$true
  if(!$e.IsRepeat -and $Songs.SelectedItem){
   if($Songs.SelectedItem.IsFolder){Toggle-Folder $Songs.SelectedItem;return}
   $selectedIndex=[Array]::IndexOf($script:files,$Songs.SelectedItem)
   if($selectedIndex -ge 0){Start-Song $selectedIndex}
  }
 }
})
$window.Add_PreviewKeyUp({
 param($sender,$e)
 if(!$Search.IsKeyboardFocusWithin -and $e.Key -eq [Windows.Input.Key]::Return){$e.Handled=$true}
})
$Volume.Add_ValueChanged({$player.Volume=$Volume.Value;$VolumeLabel.Text="{0}%" -f [Math]::Round($Volume.Value*100);Update-VolumeIcon})
$Speaker.Add_Click({$VolumePopup.IsOpen=!$VolumePopup.IsOpen})
$player.Add_MediaEnded({if($script:loopMode -eq 1){Start-Song $script:index} else {Next-Track}})
$player.Add_MediaFailed({Stop-Playback;$TrackDetails.Visibility='Collapsed';Set-StatusText $TitleText 'Text' '无法播放此文件，请选择其他歌曲'})
$Bar.Add_MouseLeftButtonDown({if([Windows.Input.Mouse]::LeftButton -eq 'Pressed'){$window.DragMove()}})
$Close.Add_Click({$VolumePopup.IsOpen=$false;$window.Hide()})
$script:pinned=$false
function Set-Pinned([bool]$value){
 $script:pinned=$value;$window.Topmost=$value
 $PinGlyph.Opacity=1.0
 $PinGlyph.Stroke=if($value){[Windows.Media.Brushes]::White}else{[Windows.Media.Brushes]::Gray}
 $PinGlyph.RenderTransform=[Windows.Media.Transform]::Identity
 $Pin.ToolTip=if($value){(Get-Text '固定悬浮：保持置顶，可关闭或 Alt+S 隐藏；点击取消固定')}else{(Get-Text '自动收起：失去焦点后隐藏；点击固定悬浮')}
 $Close.IsEnabled=$true;$Close.Opacity=1.0
 if($hideItem){$hideItem.Enabled=$true}
 if($value){$focusTimer.Stop()}
}
$focusTimer=New-Object Windows.Threading.DispatcherTimer
$focusTimer.Interval=[TimeSpan]::FromMilliseconds(200)
$focusTimer.Add_Tick({
 if($script:pinned -or !$window.IsVisible -or $window.IsActive){$focusTimer.Stop();return}
 $foreground=[MusicHotKey]::GetForegroundWindow();$foregroundPid=0
 [void][MusicHotKey]::GetWindowThreadProcessId($foreground,[ref]$foregroundPid)
 # Owned menus/dialogs/popups are part of the player, not an external focus loss.
 if($foregroundPid -eq $PID){return}
 $focusTimer.Stop();$VolumePopup.IsOpen=$false;$window.Hide()
})
$window.Add_Deactivated({if(!$script:pinned){$focusTimer.Start()}})
$window.Add_Activated({$focusTimer.Stop()})
$window.Add_IsVisibleChanged({if(!$window.IsVisible){$focusTimer.Stop()}})
$Pin.Add_Click({Set-Pinned (!$script:pinned);Save-Preferences})
Set-Pinned $false

$script:importJobs=New-Object 'System.Collections.Generic.List[object]'
function Begin-MusicImport($paths,$destination,$before=$null){
 $worker=[PowerShell]::Create()
 $task={param($libraryPath,$paths,$destination)
  $ErrorActionPreference='Stop'
  . $libraryPath
  Import-MusicFiles $paths $destination
 }
 [void]$worker.AddScript($task.ToString()).AddArgument((Join-Path $PSScriptRoot 'Library.ps1')).AddArgument($paths).AddArgument($destination)
  try {
  $script:importJobs.Add(@{Worker=$worker;Async=$worker.BeginInvoke();Root=$script:currentFolder;Before=$before;Order=@($script:files.FullName)})
 } catch { $worker.Dispose();Write-PlayerError '开始导入' $_;return }
 $importTimer.Start()
 Set-StatusText $Refresh 'ToolTip' '正在后台导入音乐…'
}
$importTimer=New-Object Windows.Threading.DispatcherTimer
$importTimer.Interval=[TimeSpan]::FromMilliseconds(300)
$importTimer.Add_Tick({
 if(!$script:importJobs.Count){$importTimer.Stop();return}
 for($j=$script:importJobs.Count-1;$j -ge 0;$j--){
  $job=$script:importJobs[$j];if(!$job.Async.IsCompleted){continue}
  try{
   $results=@($job.Worker.EndInvoke($job.Async))
   if($job.Worker.HadErrors -or !$results.Count){throw (Get-Text '导入未完成')}
   $result=$results[0]
   if($result.Paths.Count){
    $existing=if($script:folderOrders.ContainsKey($job.Root)){$script:folderOrders[$job.Root]}else{$job.Order}
    $script:folderOrders[$job.Root]=@(Get-ImportOrder $existing $result.Paths $job.Before)
    Save-JsonFile $orderFile $script:folderOrders
   }
   Request-MusicScan
   if($tray){$tray.BalloonTipTitle=(Get-Text '音乐导入');$tray.BalloonTipText=(Get-Text '已添加 {0} 首，跳过 {1} 项，失败 {2} 项。原文件已保留。' @($result.Added,$result.Skipped,$result.Failed));$tray.ShowBalloonTip(3500)}
  }catch{Write-PlayerError '导入' $_;Set-StatusText $Refresh 'ToolTip' '导入失败，请检查文件夹权限'}finally{$job.Worker.Dispose();$script:importJobs.RemoveAt($j)}
 }
})

function Get-ImportPlacement($pos){
 if(!$script:currentFolder -or !$Songs.IsVisible -or $pos.X -lt 0 -or $pos.Y -lt 0 -or $pos.X -gt $Songs.ActualWidth -or $pos.Y -gt $Songs.ActualHeight){return $null}
 $row=$null
 for($j=0;$j -lt $Songs.Items.Count;$j++){
  $candidate=$Songs.ItemContainerGenerator.ContainerFromIndex($j)
  if(!$candidate){continue}
  $top=$candidate.TranslatePoint((New-Object Windows.Point(0,0)),$Songs).Y
  if($top -le $pos.Y){$row=$candidate}
  if($pos.Y -ge $top -and $pos.Y -le $top+$candidate.ActualHeight){$row=$candidate;break}
 }
 if($row -is [Windows.Controls.ListBoxItem]){
  $target=$row.Content;$top=$row.TranslatePoint((New-Object Windows.Point(0,0)),$Songs).Y
  if($target.IsFolder){
   $first=@($script:files | Where-Object {(Get-TrackFolder $_) -ieq $target.FolderPath} | Select-Object -First 1)
   return [pscustomobject]@{Folder=$target.FolderPath;Before=$(if($first.Count){$first[0].FullName}else{$null});Y=$top+$row.ActualHeight}
  }
  $folder=Get-TrackFolder $target;$before=$target.FullName;$y=$top
  if($pos.Y -gt $top+$row.ActualHeight/2){
   $y+=$row.ActualHeight;$before=$null;$found=$false
   foreach($track in $script:files){if($found -and (Get-TrackFolder $track) -ieq $folder){$before=$track.FullName;break};if($track.FullName -eq $target.FullName){$found=$true}}
  }
  return [pscustomobject]@{Folder=$folder;Before=$before;Y=$y}
 }
 return [pscustomobject]@{Folder=$script:currentFolder;Before=$null;Y=[Math]::Min($pos.Y,$Songs.ActualHeight-3)}
}
$window.Add_PreviewDragOver({
 param($sender,$e)
 $e.Effects=[Windows.DragDropEffects]::None
 if($e.Data.GetDataPresent('SimpleDesktopMusic.Track')){
  $pos=$e.GetPosition($Songs)
  if($pos.X -ge 0 -and $pos.X -le $Songs.ActualWidth -and $pos.Y -ge 0 -and $pos.Y -le $Songs.ActualHeight){
   $e.Effects=[Windows.DragDropEffects]::Move
   $script:dragPosition=$pos;Update-DropPreview $pos;if(!$dragScrollTimer.IsEnabled){$dragScrollTimer.Start()}
  }
  if($e.Effects -eq [Windows.DragDropEffects]::None){Clear-DropPreview}
  $e.Handled=$true;return
 }
 if($e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)){
  $paths=@($e.Data.GetData([Windows.DataFormats]::FileDrop))
  if(@($paths | Where-Object {(Test-MusicFile $_) -and (Test-Path -LiteralPath $_ -PathType Leaf)}).Count){
   $placement=Get-ImportPlacement ($e.GetPosition($Songs))
   $script:importPlacement=$placement
   if($placement){
    $e.Effects=[Windows.DragDropEffects]::Copy
    $DropLine.Width=[Math]::Max(0,$Songs.ActualWidth-20)
    [Windows.Controls.Canvas]::SetLeft($DropLine,4);[Windows.Controls.Canvas]::SetTop($DropLine,[Math]::Round($placement.Y))
    $DropLine.Visibility='Visible'
   }
  }
 }
 $e.Handled=$true
})
$window.Add_PreviewDrop({
 param($sender,$e)
 $lastImportPlacement=$script:importPlacement
 $lastPreview=$script:previewIndex
 Clear-DropPreview
 $e.Handled=$true
 if($e.Data.GetDataPresent('SimpleDesktopMusic.Track')){
  $pos=$e.GetPosition($Songs)
  if($pos.X -lt 0 -or $pos.X -gt $Songs.ActualWidth -or $pos.Y -lt 0 -or $pos.Y -gt $Songs.ActualHeight){return}
  $insertAt=(Get-DropPosition $pos).Index
  if($null -ne $lastPreview){$insertAt=$lastPreview}
  $sourcePath=[string]$e.Data.GetData('SimpleDesktopMusic.Track')
  $target=$null;$after=$false
  if($insertAt -lt $Songs.Items.Count){$target=$Songs.Items[$insertAt]}
  if(!$target -or $target.IsFolder){if($insertAt -gt 0){$target=$Songs.Items[$insertAt-1];$after=$true}}
  if(!$target -or $target.IsFolder -or (Get-TrackFolder $target) -ine [IO.Path]::GetDirectoryName($sourcePath)){return}
  $realIndex=[Array]::IndexOf($script:files,$target)
  if($after){$realIndex++}
  Move-PlaylistTrack $sourcePath $realIndex
  return
 }
 if(!$e.Data.GetDataPresent([Windows.DataFormats]::FileDrop)){return}
 $paths=[string[]]$e.Data.GetData([Windows.DataFormats]::FileDrop)
 if(!$script:currentFolder -or !(Test-Path -LiteralPath $script:currentFolder -PathType Container)){
  $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
  $dialog.Description=(Get-Text '选择存放导入音乐的文件夹')
  try {if($dialog.ShowDialog() -ne 'OK'){return};Load-Folder $dialog.SelectedPath}finally{$dialog.Dispose()}
 }
 $placement=$lastImportPlacement
 if(!$placement){$placement=Get-ImportPlacement ($e.GetPosition($Songs))}
 if($placement){Begin-MusicImport $paths $placement.Folder $placement.Before}
})
Add-Type -AssemblyName Microsoft.VisualBasic
function Delete-LibraryItem($target){
 if(!$target){return}
 $folder=[bool]$target.IsFolder
 $path=if($folder){$target.FolderPath}else{$target.FullName}
 if(!(Test-Path -LiteralPath $path)){Request-MusicScan;return}
 if($folder){
  $root=[IO.Path]::GetFullPath($script:currentFolder).TrimEnd('\')
  $resolved=[IO.Path]::GetFullPath($path).TrimEnd('\')
  if($resolved -ieq $root -or !$resolved.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){
   [void][Windows.MessageBox]::Show((Get-Text '不能删除当前音乐库根目录。请选择子文件夹。'),'SimpleM');return
  }
  if([Windows.MessageBox]::Show(((Get-Text '将文件夹及其中全部文件移到回收站？')+"`n"+$path),(Get-Text '删除文件夹'),'YesNo','Warning','No') -ne 'Yes'){return}
 }
 $current=$null;if($script:index -ge 0){$current=$script:files[$script:index].FullName}
 $stop=$current -and ($current -ieq $path -or ($folder -and $current.StartsWith($path.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)))
 if($stop){Stop-Playback}
 try{
  if($folder){[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($path,[Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,[Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin,[Microsoft.VisualBasic.FileIO.UICancelOption]::ThrowException)}
  else{[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($path,[Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,[Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin,[Microsoft.VisualBasic.FileIO.UICancelOption]::ThrowException)}
 }catch{[void][Windows.MessageBox]::Show((Get-Text '未能移到回收站：')+$_.Exception.Message,'SimpleM')}
 Request-MusicScan
}
$Songs.Add_PreviewKeyDown({param($sender,$e) if($e.Key -eq [Windows.Input.Key]::Delete){$e.Handled=$true;if(!$e.IsRepeat){Delete-LibraryItem $Songs.SelectedItem}}})
$Songs.Add_PreviewMouseRightButtonDown({param($sender,$e)
 $row=[Windows.Controls.ItemsControl]::ContainerFromElement($Songs,[Windows.DependencyObject]$e.OriginalSource)
 if($row -isnot [Windows.Controls.ListBoxItem]){return}
 $row.IsSelected=$true
 $context=New-Object Windows.Controls.ContextMenu;$remove=New-Object Windows.Controls.MenuItem
 $remove.Header=if($row.Content.IsFolder){(Get-Text '删除文件夹（移到回收站）')}else{(Get-Text '移到回收站（Del）')}
 $remove.Tag=$row.Content;$remove.Add_Click({param($sender,$e) Delete-LibraryItem $sender.Tag})
 [void]$context.Items.Add($remove);$context.PlacementTarget=$row;$context.IsOpen=$true;$e.Handled=$true
})
$script:initialized=$false
$window.Add_Loaded({if($script:initialized){return};$script:initialized=$true;$area=[System.Windows.SystemParameters]::WorkArea;$window.Left=$area.Right-$window.Width-18;$window.Top=$area.Top+([Math]::Max(0,($area.Height-$window.Height)/2));if(Test-Path $config){Load-Folder ([IO.File]::ReadAllText($config))};if(Test-Path -LiteralPath $preferences){
 try {
  $saved=Get-Content -LiteralPath $preferences -Raw | ConvertFrom-Json
  Set-Language $saved.Language
  $Volume.Value=[Math]::Max(0.0,[Math]::Min(1.0,[double]$saved.Volume))
  $script:loopMode=[Math]::Max(0,[Math]::Min(2,[int]$saved.Mode))
  if($saved.Scope -eq 'folder'){$script:playScope='folder'};Update-ModeHint
  Set-CompactView ([bool]$saved.Compact)
  if($null -ne $saved.ListVisible){Set-ListVisible ([bool]$saved.ListVisible)}
  if($null -ne $saved.PinnedV2){Set-Pinned ([bool]$saved.PinnedV2)}else{Set-Pinned $false}
  $window.Left=[Math]::Max($area.Left,[Math]::Min($area.Right-$window.Width,[double]$saved.Left))
  $window.Top=[Math]::Max($area.Top,[Math]::Min($area.Bottom-$window.Height,[double]$saved.Top))
 }catch{}
}})
Add-Type -AssemblyName System.Drawing

$script:exiting=$false
$script:hotkeyRegistered=$false
$tray=New-Object System.Windows.Forms.NotifyIcon
$tray.Icon=[System.Drawing.SystemIcons]::Application
$tray.Text='SimpleM · Alt+S'
$menu=New-Object System.Windows.Forms.ContextMenuStrip
$showItem=$menu.Items.Add((Get-Text '显示播放器  Alt+S'))
$hideItem=$menu.Items.Add((Get-Text '隐藏播放器'))
$listItem=New-Object System.Windows.Forms.ToolStripMenuItem((Get-Text '显示歌曲列表'))
$listItem.Checked=$true
$listItem.Add_Click({Set-ListVisible (!$script:listVisible);Save-Preferences})
[void]$menu.Items.Add($listItem)
$revealItem=$menu.Items.Add((Get-Text '在文件夹中显示当前歌曲'))
$revealItem.Add_Click({
 if($script:index -ge 0 -and $script:index -lt $script:files.Count){
  $path=$script:files[$script:index].FullName
  if(Test-Path -LiteralPath $path){Start-Process explorer.exe -ArgumentList ('/select,"'+$path+'"')}
 }
})
$menu.Add_Opening({$revealItem.Enabled=($script:index -ge 0 -and $script:index -lt $script:files.Count)})
$autoItem=New-Object System.Windows.Forms.ToolStripMenuItem((Get-Text '开机自启动'))
$autoItem.CheckOnClick=$true
[void]$menu.Items.Add($autoItem)
$languageMenu=New-Object System.Windows.Forms.ToolStripMenuItem('语言 / Language')
$chineseItem=$languageMenu.DropDownItems.Add('中文')
$englishItem=$languageMenu.DropDownItems.Add('English')
$chineseItem.Add_Click({Set-Language 'zh';Save-Preferences})
$englishItem.Add_Click({Set-Language 'en';Save-Preferences})
[void]$menu.Items.Add($languageMenu)
[void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$exitItem=$menu.Items.Add((Get-Text '退出'))
$tray.ContextMenuStrip=$menu
$tray.Visible=$true
function Toggle-Player {
 if($window.IsVisible){$VolumePopup.IsOpen=$false;$window.Hide()}else{Show-Player}
}
function Show-Player {
 $focusTimer.Stop();$window.Show();$window.WindowState='Normal';$window.Topmost=$true;$window.Topmost=$script:pinned
 [void]$window.Activate()
 Sync-PlaybackProgress
 $VolumePopup.IsOpen=$false
 Focus-SongList
 if($script:handle){[MusicHotKey]::DisableSystemMenu($script:handle)}
}
$showItem.Add_Click({Show-Player})
$tray.Add_DoubleClick({Show-Player})
$hideItem.Enabled=$true
$hideItem.Add_Click({$VolumePopup.IsOpen=$false;$window.Hide()})
$legacyStartupLink=Join-Path ([Environment]::GetFolderPath('Startup')) 'SimpleDesktopMusic.lnk'
$startupLink=Join-Path ([Environment]::GetFolderPath('Startup')) 'SimpleM.lnk'
function Set-AutoStart([bool]$enabled) {
 if($enabled){
  $shell=New-Object -ComObject WScript.Shell
  $shortcut=$shell.CreateShortcut($startupLink)
  $shortcut.TargetPath=Join-Path $env:WINDIR 'System32\wscript.exe'
  $shortcut.Arguments='//B //Nologo "'+(Join-Path $PSScriptRoot '启动播放器.vbs')+'"'
  $shortcut.WorkingDirectory=$PSScriptRoot
  $shortcut.Description='SimpleM桌面播放器'
  $shortcut.Save()
  if(Test-Path -LiteralPath $legacyStartupLink){Remove-Item -LiteralPath $legacyStartupLink}
 } else {
  foreach($link in @($startupLink,$legacyStartupLink)){
   if(Test-Path -LiteralPath $link){Remove-Item -LiteralPath $link -ErrorAction Stop}
  }
 }
}
$autoItem.Add_Click({
 try {Set-AutoStart $autoItem.Checked} catch {$autoItem.Checked=(Test-Path -LiteralPath $startupLink) -or (Test-Path -LiteralPath $legacyStartupLink);[System.Windows.MessageBox]::Show((Get-Text '无法修改开机启动设置：')+$_.Exception.Message,'SimpleM')}
})
New-Item -ItemType Directory -Force $settings | Out-Null
$startupMarker=Join-Path $settings 'startup-configured.txt'
if(!(Test-Path -LiteralPath $startupMarker)){
 try {Set-AutoStart $true;[IO.File]::WriteAllText($startupMarker,'configured')} catch {[System.Windows.MessageBox]::Show((Get-Text '开机启动未设置成功，可在托盘菜单中重试。'),'SimpleM')}
}
$autoItem.Checked=(Test-Path -LiteralPath $startupLink) -or (Test-Path -LiteralPath $legacyStartupLink)
if($autoItem.Checked){try{Set-AutoStart $true}catch{}}
$exitItem.Add_Click({$script:exiting=$true;$window.Close()})
$window.Add_Closing({param($sender,$eventArgs) if(!$script:exiting){$eventArgs.Cancel=$true;$VolumePopup.IsOpen=$false;$window.Hide()}})
$window.Add_SourceInitialized({
 $script:handle=(New-Object Windows.Interop.WindowInteropHelper($window)).Handle
 [MusicHotKey]::DisableSystemMenu($script:handle)
 $script:source=[Windows.Interop.HwndSource]::FromHwnd($script:handle)
 $script:hook=[Windows.Interop.HwndSourceHook]{param($hwnd,$msg,$wParam,$lParam,[ref]$handled)
  if($msg -eq 0x0312 -and $wParam.ToInt32() -eq 7301){Toggle-Player;$handled.Value=$true}
  # Alt+Space is a native system keystroke and can bypass WPF's normal Space handler.
  if(!$Search.IsKeyboardFocusWithin -and ($msg -eq 0x0100 -or $msg -eq 0x0101 -or $msg -eq 0x0104 -or $msg -eq 0x0105) -and $wParam.ToInt32() -eq 0x20){
   $handled.Value=$true
   if(($msg -eq 0x0100 -or $msg -eq 0x0104) -and ($lParam.ToInt64() -band 0x40000000) -eq 0){
    $Play.RaiseEvent((New-Object Windows.RoutedEventArgs([Windows.Controls.Button]::ClickEvent)))
   }
   return [IntPtr]::Zero
  }
  # Prevent the OS menu from stealing keyboard focus after an Alt-based activation.
  if($msg -eq 0x0112 -and ($wParam.ToInt64() -band 0xFFF0) -eq 0xF100){
   $handled.Value=$true
   return [IntPtr]::Zero
  }
  return [IntPtr]::Zero
 }
 $script:source.AddHook($script:hook)
 $script:hotkeyRegistered=[MusicHotKey]::RegisterHotKey($script:handle,7301,0x4001,0x53)
 if(!$script:hotkeyRegistered){$tray.BalloonTipTitle=(Get-Text '快捷键被占用');$tray.BalloonTipText=(Get-Text 'Alt+S 注册失败，请双击托盘图标唤出播放器。');$tray.ShowBalloonTip(5000)}
})
$window.Add_Closed({
 Save-Preferences
 $window.Dispatcher.BeginInvokeShutdown([Windows.Threading.DispatcherPriority]::Background)
})
$activationTimer = New-Object Windows.Threading.DispatcherTimer
$activationTimer.Interval = [TimeSpan]::FromMilliseconds(200)
$activationTimer.Add_Tick({if($instanceSignal.WaitOne(0)){Show-Player}})
Set-Language $script:language
$activationTimer.Start()
Show-Player
[System.Windows.Threading.Dispatcher]::Run()
} finally {
 # Independent cleanup steps ensure one failure cannot strand the tray or mutex.
 foreach($timer in @($activationTimer,$focusTimer,$importTimer,$scanTimer,$watchTimer,$dragScrollTimer,$progressTimer)){
  if($timer){try{$timer.Stop()}catch{}}
 }
 foreach($job in @($(if($script:importJobs){$script:importJobs.ToArray()})) + @($script:scanJob)){
  if(!$job){continue}
  try{$job.Worker.Stop()}catch{}
  try{$job.Worker.Dispose()}catch{}
  if($job.Runspace){try{$job.Runspace.Dispose()}catch{}}
 }
 if($script:folderWatch){try{$script:folderWatch.Dispose()}catch{}}
 if($player){try{$player.Close()}catch{}}
 if($script:hotkeyRegistered){try{[void][MusicHotKey]::UnregisterHotKey($script:handle,7301)}catch{}}
 if($script:source -and $script:hook){try{$script:source.RemoveHook($script:hook)}catch{}}
 if($tray){try{$tray.Visible=$false;$tray.Dispose()}catch{}}
 if($menu){try{$menu.Dispose()}catch{}}
 if($ownsInstance){$instanceMutex.ReleaseMutex()}
 $instanceMutex.Dispose()
 $instanceSignal.Dispose()
}