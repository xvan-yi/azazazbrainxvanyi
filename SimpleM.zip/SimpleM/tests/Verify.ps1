﻿param([string]$Root = (Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference = 'Stop'
$checks = 0
function Assert($Condition, [string]$Message) {
    if (!$Condition) { throw $Message }
    $script:checks++
    Write-Output "PASS $Message"
}
foreach ($file in Get-ChildItem -LiteralPath $Root -Filter *.ps1) {
    $tokens=$null;$errors=$null
    $null=[Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    Assert ($errors.Count -eq 0) ("PowerShell syntax: " + $file.Name)
}
. (Join-Path $Root 'Library.ps1')
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms
Add-Type -Path (Join-Path $Root 'Native.cs')
[xml]$xaml=[IO.File]::ReadAllText((Join-Path $Root 'Player.xaml'))
$window=[Windows.Markup.XamlReader]::Load((New-Object Xml.XmlNodeReader $xaml))
Assert ($null -ne $window.FindName('Songs')) 'WPF markup loads with playlist control'
Assert ((Format-Time 3661) -eq '1:01:01') 'Hour-long playback time'
Assert ((Format-Time -1) -eq '0:00') 'Negative playback time'
$testRoot=Join-Path $PSScriptRoot ('test-' + [Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($testRoot)
try {
    $state=Join-Path $testRoot 'nested/settings.json'
    Save-JsonFile $state @{Title='中文';Volume=0.7}
    Save-JsonFile $state @{Title='更新';Volume=0.3}
    $saved=Get-Content -LiteralPath $state -Raw | ConvertFrom-Json
    Assert ($saved.Title -eq '更新' -and $saved.Volume -eq 0.3) 'Atomic replacement preserves Unicode JSON'
    Assert (@(Get-ChildItem -LiteralPath (Split-Path $state)).Count -eq 1) 'Atomic save leaves no temporary files'
    $lock=[IO.File]::Open($state,'Open','Read','None')
    $failed=$false
    try {Save-JsonFile $state @{Title='broken'}} catch {$failed=$true} finally {$lock.Dispose()}
    Assert $failed 'Locked settings report failure'
    Assert ((Get-Content -LiteralPath $state -Raw | ConvertFrom-Json).Title -eq '更新') 'Failed save preserves previous settings'
    Assert (@(Get-ChildItem -LiteralPath (Split-Path $state)).Count -eq 1) 'Failed save cleans temporary file'
    $order=@(Get-ImportOrder @('A/one','A/two') @('A/new') 'A/two')
    Assert (($order -join ',') -eq 'A/one,A/new,A/two') 'Import inserts before requested song'
    $order=@(Get-ImportOrder @('A/one') @('A/one','A/new') '')
    Assert (($order -join ',') -eq 'A/one,A/new') 'Import appends without duplicate songs'
    $source=Join-Path $testRoot 'source';$destination=Join-Path $testRoot 'target'
    [void][IO.Directory]::CreateDirectory($source);[void][IO.Directory]::CreateDirectory($destination)
    $song=Join-Path $source 'test.mp3';[IO.File]::WriteAllText($song,'original')
    $result=Import-MusicFiles @($song) $destination
    $again=Import-MusicFiles @($song) $destination
    Assert ($result.Added -eq 1 -and $again.Added -eq 1 -and $again.Paths[0].EndsWith('test (1).mp3')) 'Import collision gets a unique filename'
    Assert ([IO.File]::ReadAllText($song) -eq 'original') 'Import preserves original file'
    $skip=Import-MusicFiles @($result.Paths[0],(Join-Path $testRoot 'missing.mp3')) $destination
    Assert ($skip.Skipped -eq 2 -and $skip.Added -eq 0) 'Import skips same file and missing file'
    $worker=[PowerShell]::Create()
    try {
        [void]$worker.AddScript('param($libraryPath,$paths,$destination) $ErrorActionPreference="Stop"; . $libraryPath; Import-MusicFiles $paths $destination').AddArgument((Join-Path $Root 'Library.ps1')).AddArgument(@($song)).AddArgument($destination)
        $async=$worker.BeginInvoke();$background=@($worker.EndInvoke($async))
        Assert (!$worker.HadErrors -and $background[0].Added -eq 1) 'Import function works in background worker'
    } finally {$worker.Dispose()}
    $scan=Get-MusicLibrary $destination @{} @() @()
    Assert ($scan.Tracks.Count -eq 3) 'Full scan finds imported songs'
    [IO.File]::AppendAllText($result.Paths[0],'changed')
    $updated=Get-MusicLibrary $destination $scan.Cache @($result.Paths[0]) $scan.Tracks
    Assert ($updated.Tracks.Count -eq 3 -and $updated.Cache.Count -eq 3) 'Incremental scan discards obsolete metadata versions'
    [IO.File]::Delete($again.Paths[0])
    $removed=Get-MusicLibrary $destination $updated.Cache @($again.Paths[0]) $updated.Tracks
    Assert ($removed.Tracks.Count -eq 2 -and $removed.Cache.Count -eq 2) 'Incremental scan removes deleted songs and cache entries'
    $mixedSource=Join-Path $testRoot 'mixed-source'
    $mixedTarget=Join-Path $testRoot 'mixed-target'
    [void][IO.Directory]::CreateDirectory($mixedSource)
    [void][IO.Directory]::CreateDirectory($mixedTarget)
    $mixedPaths=@(foreach($extension in '.MP3','.WaV','.wma','.m4a','.aac','.FLAC','.txt','.ogg'){
        $file=Join-Path $mixedSource ('song'+$extension)
        [IO.File]::WriteAllText($file,'fixture')
        $file
    })
    $fakeDirectory=Join-Path $mixedSource 'directory.mp3'
    [void][IO.Directory]::CreateDirectory($fakeDirectory)
    $mixed=Import-MusicFiles ($mixedPaths + @($fakeDirectory)) $mixedTarget
    Assert ($mixed.Added -eq 6 -and $mixed.Skipped -eq 3 -and $mixed.Failed -eq 0) 'Mixed import accepts six formats case-insensitively and skips unsupported files/directories'
    $mixedScan=Get-MusicLibrary $mixedSource @{} @() @()
    Assert ($mixedScan.Tracks.Count -eq 6) 'Scanner and importer recognize the same six formats'
    $duplicates=Import-MusicFiles $mixedPaths $mixedTarget
    Assert ($duplicates.Added -eq 6 -and @($duplicates.Paths | Where-Object {$_ -notlike '* (1).*'}).Count -eq 0) 'All six formats retain collision-safe naming'
    Assert (@($mixedPaths | Where-Object {[IO.File]::ReadAllText($_) -ne 'fixture'}).Count -eq 0) 'Mixed import leaves every original unchanged'
    $worker=[PowerShell]::Create()
    try {
        [void]$worker.AddScript('param($libraryPath,$paths,$destination) $ErrorActionPreference="Stop"; . $libraryPath; Import-MusicFiles $paths $destination').AddArgument((Join-Path $Root 'Library.ps1')).AddArgument($mixedPaths).AddArgument($mixedTarget)
        $async=$worker.BeginInvoke();$background=@($worker.EndInvoke($async))
        Assert (!$worker.HadErrors -and $background[0].Added -eq 6 -and $background[0].Skipped -eq 2) 'Background worker imports mixed formats using the shared library'
    } finally {$worker.Dispose()}
    $watch=New-Object MusicFolderWatch($destination)
    try {
        [IO.File]::WriteAllText((Join-Path $destination 'watch.mp3'),'watch')
        Start-Sleep -Milliseconds 1400
        Assert ($watch.Consume() -and @($watch.Drain()).Count -gt 0) 'Folder watcher reports file changes'
    } finally {$watch.Dispose()}
} finally {
    $resolved=[IO.Path]::GetFullPath($testRoot)
    if (!$resolved.StartsWith([IO.Path]::GetFullPath($PSScriptRoot) + [IO.Path]::DirectorySeparatorChar)) { throw 'Unsafe test cleanup path' }
    # Keep fixtures under work for inspection.
}
Write-Output "$checks checks passed."
